$(document)
  .ready(function() {

    console.log($('.filter.menu .item'));
    
    $('.filter.menu .item')
      .tab()
    ;
/*
    $('.ui.rating')
      .rating({
        clearable: true
      })
    ;

    $('.ui.sidebar')
      .sidebar('attach events', '.launch.button')
    ;

    $('.ui.dropdown')
      .dropdown()
    ;
*/
  })
;
