<template lang="jade">
  h1.ui.dividing.header Status
  .ui.segment(:class="{loading: false}")
    table.ui.table.large.green.selectable.very.basic
      thead
        tr
          th.collapsing.right sol id
          th problem
          th user
          th status
          th score
          th time(s)
          th space(MB)
          th.collapsing lang
          th.collapsing round
      tbody
        tr.red(v-for="sol in solutions")
          td
            code-link(:sid="sol._id")
          td
            problem(:prob="sol.prob")
          td
            user(:uid="sol.user")
          td {{sol.final.status}}
          td {{sol.final.score}}
          td {{sol.final.time}}
          td {{sol.final.space}}
          td {{sol.lang}}
          td(v-if="sol.round")
            round(:rnd="sol.round")
          td(v-else)
  .ui.icon.labeled.button.floated.right.primary
    i.icon.refresh
    | refresh
</template>

<script lang="vue-livescript">
require! {
  \debug
  \co
  \vue
  \../format
}

log = debug \dollast:component:solution:list

module.exports =
  data: ->
    solutions: []
  route:
    data: co.wrap ~>*
      {data} = yield vue.http.get \/solution
      solutions: data
  components:
    format

</script>
