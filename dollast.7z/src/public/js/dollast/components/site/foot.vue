<template lang="jade">
  .ui.divider.horizontal Yuping Luo @ 2016
</template>
