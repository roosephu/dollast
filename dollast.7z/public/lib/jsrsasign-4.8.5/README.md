jsrsasign
=========

The 'jsrsasign' is an opensource free pure JavaScript cryptographic library supports RSA/RSAPSS/ECDSA/DSA signing/validation, ASN.1, PKCS#1/5/8 private/public key, X.509 certificate, CRL, CMS SignedData, TimeStamp and CAdES and JSON Web Signature(JWS)/Token(JWT)/Key(JWK).

Public page is http://kjur.github.com/jsrsasign .

Your bugfix and pull request contribution are always welcomed :)
